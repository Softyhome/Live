# -*- coding: utf-8 -*-
{
    'name': "Stock Qty",

    'summary': """
        Update Stock On hand """,
    'author': "Ayush Gupta",
    'category': 'Extra',
    'version': '0.1',
    'depends': ['base','stock'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/customer_export.xml'
    ],
}
